package com.adnant1.stock_price_notification_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockPriceNotificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
