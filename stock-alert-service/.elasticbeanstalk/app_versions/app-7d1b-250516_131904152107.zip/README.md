Stock Price Notification Service
